package com.goodies.customer.pojo;

/**
 * @Author: pxp167
 * @Date: 9/26/2018
 *
 */

public class Address {
  private static final long serialVersionUID = 1L;

  private long addressId;

  private String flatNo;

  private String buildingName;

  private String city;

  private String state;

  private String country;

  private String pinCode;

  private String location;

  private String latitude;

  private String longitude;

  public long getAddressId() {
    return addressId;
  }

  public void setAddressId(long addressId) {
    this.addressId = addressId;
  }

  public String getFlatNo() {
    return flatNo;
  }

  public void setFlatNo(String flatNo) {
    this.flatNo = flatNo;
  }

  public String getBuildingName() {
    return buildingName;
  }

  public void setBuildingName(String buildingName) {
    this.buildingName = buildingName;
  }

  public String getCity() {
    return city;
  }

  public void setCity(String city) {
    this.city = city;
  }

  public String getState() {
    return state;
  }

  public void setState(String state) {
    this.state = state;
  }

  public String getCountry() {
    return country;
  }

  public void setCountry(String country) {
    this.country = country;
  }

  public String getPinCode() {
    return pinCode;
  }

  public void setPinCode(String pinCode) {
    this.pinCode = pinCode;
  }

  public String getLocation() {
    return location;
  }

  public void setLocation(String location) {
    this.location = location;
  }

  public String getLatitude() {
    return latitude;
  }

  public void setLatitude(String latitude) {
    this.latitude = latitude;
  }

  public String getLongitude() {
    return longitude;
  }

  public void setLongitude(String longitude) {
    this.longitude = longitude;
  }

}
