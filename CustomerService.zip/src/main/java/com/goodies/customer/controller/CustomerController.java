package com.goodies.customer.controller;

import com.goodies.customer.pojo.User;
import com.goodies.customer.service.CustomerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;


/**
 * @Author: pxp167
 * @Date: 11/1/2018
 *
 */
@RestController
public class CustomerController {

  @Autowired
  CustomerService customerService;

  @RequestMapping(value = "/create", method = RequestMethod.POST)
  public void createUser(@RequestBody User user){
    customerService.create(user);
  }



}
