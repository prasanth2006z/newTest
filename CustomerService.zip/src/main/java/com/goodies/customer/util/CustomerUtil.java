package com.goodies.customer.util;

import org.springframework.http.HttpHeaders;

/**
 * @Author: pxp167
 * @Date: 11/1/2018
 *
 */
public class CustomerUtil {
  public static HttpHeaders getHttpHeaders() {
    final HttpHeaders httpHeaders = new HttpHeaders();

    httpHeaders.add("Content-Type", "application/json");

    return httpHeaders;
  }
}
