package com.goodies.customer.service.impl;

import com.goodies.customer.pojo.User;
import com.goodies.customer.service.CustomerService;
import com.goodies.customer.util.CustomerUtil;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import java.util.Date;

/**
 * @Author: pxp167
 * @Date: 11/1/2018
 *
 */
public class CustomerServiceImpl implements CustomerService {

  private static final Logger logger = LogManager.getLogger(CustomerServiceImpl.class);

  @Autowired
  private RestTemplate restTemplate;

  @Override public void create(User user) {
    user.setCreationDate(new Date());
    try {
      final HttpEntity<?> httpEntity = new HttpEntity<Object>(user);
      final ResponseEntity<String> response = restTemplate.exchange("https://localhost:8090/create", HttpMethod.POST, httpEntity, String.class, CustomerUtil.getHttpHeaders());
    }catch(Exception e){
      logger.error(user);
      logger.error(e);
    }

  }
}
