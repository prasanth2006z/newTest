package com.goodies.customer.service;

import com.goodies.customer.pojo.User;

/**
 * @Author: pxp167
 * @Date: 11/1/2018
 *
 */
public interface CustomerService {

  void create(User user);
}
