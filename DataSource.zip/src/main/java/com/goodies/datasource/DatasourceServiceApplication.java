package com.goodies.datasource;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DatasourceServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(DatasourceServiceApplication.class, args);
	}
}
