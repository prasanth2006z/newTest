package com.goodies.datasource.dao;

import com.goodies.datasource.entity.Order;
import org.springframework.data.repository.CrudRepository;

/**
 * @Author: pxp167
 * @Date: 9/28/2018
 *
 */
public interface OrderDao extends CrudRepository<Order, Long> {
}
