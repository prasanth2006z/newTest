package com.goodies.datasource.service;

import com.goodies.datasource.entity.Order;

import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * @Author: pxp167
 * @Date: 9/26/2018
 *
 */
public interface OrderService {

  /**
   *
   * @param order
   */
  void save(Order order);

  /**
   *
   * @return
   */
  List<Order>  getOrders();

  /**
   *
   * @param orders
   */
  void updateorders(List<Order> orders);

  /**
   *
   * @param orderId
   */
  void deleteOrderbyId(long orderId);

  /**
   *
   * @param userId
   * @return
   */
  List<Order> getPreviousOrderHistory(long userId);

  /**
   *
   * @param fromDate
   * @param toDate
   * @return
   */
  Map<Long,String> getFeedBacks(Date fromDate, Date toDate);

  /**
   *
   * @param buildingName
   * @return
   */
  List<Order>  getOrders(String buildingName);

}
