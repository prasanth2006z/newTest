package com.goodies.datasource.service.impl;

import com.goodies.datasource.dao.ProductDao;
import com.goodies.datasource.entity.Product;
import com.goodies.datasource.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

/**
 * @Author: pxp167
 * @Date: 9/28/2018
 *
 */
public class ProductServiceImpl implements ProductService {

  @Autowired
  private ProductDao productDao;

  @Override public void save(Product product) {
    productDao.save(product);
  }

  @Override public List<Product> getProducts() {
    return (List<Product>) productDao.findAll();

  }
}
