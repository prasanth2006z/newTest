package com.goodies.datasource.service;

import com.goodies.datasource.entity.User;

/**
 * @Author: pxp167
 * @Date: 9/26/2018
 *
 */
public interface UserService {

  void createUser(User user);

  void updateUser(User user);

  void deleteUser(User user);

  Iterable<User> getUsers();
}
