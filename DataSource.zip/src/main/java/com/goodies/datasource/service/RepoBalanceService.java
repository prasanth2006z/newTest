package com.goodies.datasource.service;

/**
 * @Author: pxp167
 * @Date: 9/26/2018
 *
 */
public interface RepoBalanceService {

  /**
   *
   * @param itemId
   * @return
   */
  int getAvailableBalance(long itemId);

  /**
   *
   * @param itemId
   * @param quantity
   */
  void updateRepoBalance(long itemId, int quantity);


}
