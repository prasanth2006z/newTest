package com.goodies.datasource.service.impl;

import com.goodies.datasource.dao.UserDao;
import com.goodies.datasource.entity.User;
import com.goodies.datasource.service.UserService;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * @Author: pxp167
 * @Date: 9/28/2018
 *
 */
public class UserServiceImpl implements UserService {

  private static final Logger logger = LogManager.getLogger(UserServiceImpl.class);

  @Autowired
  private UserDao userDao;

  @Override public void createUser(User user) {
    logger.trace(user);
    userDao.save(user);
  }

  @Override public void updateUser(User user) {
    userDao.save(user);
  }

  @Override public void deleteUser(User user) {
    userDao.delete(user);
  }

  @Override public Iterable<User> getUsers() {return userDao.findAll(); }
}
