package com.goodies.datasource.controller;

import com.goodies.datasource.entity.User;
import com.goodies.datasource.service.UserService;
import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
/**
 * @Author: pxp167
 * @Date: 11/1/2018
 *
 */
@RestController
public class UserController {
  private static final Logger logger = LogManager.getLogger(UserController.class);

  @Autowired
  UserService  userService;

  @RequestMapping(value = "/create", method = RequestMethod.POST)
  public void createUser(@RequestBody User user){
    logger.error(user);
    userService.createUser(user);
  }
}

