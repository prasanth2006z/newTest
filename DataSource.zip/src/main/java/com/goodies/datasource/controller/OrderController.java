package com.goodies.datasource.controller;


import com.goodies.datasource.entity.Order;
import com.goodies.datasource.service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

/**
 * @Author: pxp167
 * @Date: 10/8/2018
 *
 */
@RestController
public class OrderController {

  @Autowired
  private OrderService orderService;

  @RequestMapping(value = "/order", method = RequestMethod.POST)
  public void saveOrder(Order order){
    orderService.save(order);

  }
}

