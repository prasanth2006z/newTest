package com.goodies.datasource.jdbc;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import java.sql.*;

/**
 * @Author: pxp167
 * @Date: 11/1/2018
 *
 */
@Configuration
@ConfigurationProperties("spring.datasource")
public class DBConnector {
  private static Connection connection = null;

  /*private static String URL;
  private static String USER_NAME;
  private static String PASSWORD;

  public static String getURL() {
    return URL;
  }

  public static void setURL(String URL) {
    DBConnector.URL = URL;
  }

  public static String getUserName() {
    return USER_NAME;
  }

  public static void setUserName(String userName) {
    USER_NAME = userName;
  }

  public static String getPASSWORD() {
    return PASSWORD;
  }

  public static void setPASSWOR(String PASSWORD) {
    DBConnector.PASSWORD = PASSWORD;
  }*/

  /**
   *
   * @return
   * @throws Exception
   */
  public static Connection initialiseDatabaseConnection() throws Exception{
    if (connection == null) {
      connection = DriverManager.getConnection(DatasourceParamsConfig.getURL(),DatasourceParamsConfig.getUserName(),DatasourceParamsConfig.getPASSWORD());
    }
    return connection;

  }

  /**
   *
   * @return
   */
  public static boolean closeConnection() {
    boolean flag=true;
    if (connection != null){
      try {
        connection.close();
      } catch (SQLException e) {
        flag = false;
      }
    }
    return flag;
  }


  /**
   *
   * @param preparedStatement
   * @param resultSet
   */
  public static void closingPreparedStatement(PreparedStatement preparedStatement, ResultSet resultSet) {
    try {
      if (preparedStatement != null) {
        preparedStatement.close();
        resultSet.close();
      }
    } catch (SQLException sqlException) {

    }
  }
}
