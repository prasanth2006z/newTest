package com.goodies.datasource.jdbc;

import com.amazonaws.auth.DefaultAWSCredentialsProviderChain;
import com.goodies.datasource.constants.ApplicationConstants;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.URL;
import java.security.KeyStore;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.sql.*;
import java.util.Properties;
/**
 * @Author: pxp167
 * @Date: 11/1/2018
 *
 */
//@Configuration
//@ConfigurationProperties("spring.datasource")
public class AWSDataSourceConnector {
  private static Connection connection = null;

  //AWS Credentials of the IAM user with policy enabling IAM Database Authenticated access to the db by the db user.
  private static final DefaultAWSCredentialsProviderChain creds = new DefaultAWSCredentialsProviderChain();

  /**
   * This method returns a connection to the db instance authenticated using IAM Database Authentication
   * @return
   * @throws Exception
   */
  private static Connection initialiseDatabaseConnection() throws Exception {
    if (connection == null) {
      setSslProperties();
      connection =  DriverManager.getConnection(DatasourceParamsConfig.getURL(), setMySqlConnectionProperties());
    }
    return connection;

  }

  /**
   * This method sets the mysql connection properties which includes the IAM Database Authentication token
   * as the password. It also specifies that SSL verification is required.
   * @return
   */
  private static Properties setMySqlConnectionProperties() {
    Properties mysqlConnectionProperties = new Properties();
    mysqlConnectionProperties.setProperty("verifyServerCertificate",DatasourceParamsConfig.getVerifyServerCertificate());
    mysqlConnectionProperties.setProperty("useSSL", DatasourceParamsConfig.getUseSsl());
    mysqlConnectionProperties.setProperty("user",DatasourceParamsConfig.getUserName());
    mysqlConnectionProperties.setProperty("password",DatasourceParamsConfig.getPASSWORD());
    return mysqlConnectionProperties;
  }

  /**
   * This method sets the SSL properties which specify the key store file, its type and password:
   * @throws Exception
   */
  private static void setSslProperties() throws Exception {
    System.setProperty("javax.net.ssl.trustStore", createKeyStoreFile());
    System.setProperty("javax.net.ssl.trustStoreType", ApplicationConstants.KEY_STORE_TYPE);
    System.setProperty("javax.net.ssl.trustStorePassword", ApplicationConstants.DEFAULT_KEY_STORE_PASSWORD);
  }

  /**
   * This method returns the path of the Key Store File needed for the SSL verification during the IAM Database Authentication to
   * the db instance.
   * @return
   * @throws Exception
   */
  private static String createKeyStoreFile() throws Exception {
    return createKeyStoreFile(createCertificate()).getPath();
  }

  /**
   *  This method generates the SSL certificate
   * @return
   * @throws Exception
   */
  private static X509Certificate createCertificate() throws Exception {
    CertificateFactory certFactory = CertificateFactory.getInstance("X.509");
    URL url = new File(ApplicationConstants.SSL_CERTIFICATE).toURI().toURL();

    if (url == null) {
      throw new Exception();
    }
    try (InputStream certInputStream = url.openStream()) {
      return (X509Certificate) certFactory.generateCertificate(certInputStream);
    }
  }

  /**
   * This method creates the Key Store File
   * @param rootX509Certificate - the SSL certificate to be stored in the KeyStore
   * @return
   * @throws Exception
   */
  private static File createKeyStoreFile(X509Certificate rootX509Certificate) throws Exception {
    File keyStoreFile = File.createTempFile(ApplicationConstants.KEY_STORE_FILE_PREFIX, ApplicationConstants.KEY_STORE_FILE_SUFFIX);
    try (FileOutputStream fos = new FileOutputStream(keyStoreFile.getPath())) {
      KeyStore ks = KeyStore.getInstance(ApplicationConstants.KEY_STORE_TYPE, ApplicationConstants.KEY_STORE_PROVIDER);
      ks.load(null);
      ks.setCertificateEntry("rootCaCertificate", rootX509Certificate);
      ks.store(fos, ApplicationConstants.DEFAULT_KEY_STORE_PASSWORD.toCharArray());
    }
    return keyStoreFile;
  }

  /**
   *
   * @return
   */
  public static boolean closeConnection() {
    boolean flag=true;
    if (connection != null){
      try {
        connection.close();
      } catch (SQLException e) {
        flag = false;
      }
    }
    return flag;
  }


  /**
   *
   * @param preparedStatement
   * @param resultSet
   */
  public static void closingPreparedStatement(PreparedStatement preparedStatement, ResultSet resultSet) {
    try {
      if (preparedStatement != null) {
        preparedStatement.close();
        resultSet.close();
      }
    } catch (SQLException sqlException) {

    }
  }
}
