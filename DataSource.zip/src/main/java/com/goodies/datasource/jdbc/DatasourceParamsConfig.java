package com.goodies.datasource.jdbc;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

/**
 * @Author: pxp167
 * @Date: 11/1/2018
 *
 */
@Configuration
@ConfigurationProperties("spring.datasource")
public class DatasourceParamsConfig {
  private static String URL;
  private static String USER_NAME;
  private static String PASSWORD;
  private static String VERIFY_SERVER_CERTIFICATE;
  private static String USE_SSL;

  public static String getURL() {
    return URL;
  }

  public static void setURL(String URL) {
    DatasourceParamsConfig.URL = URL;
  }

  public static String getUserName() {
    return USER_NAME;
  }

  public static void setUserName(String userName) {
    USER_NAME = userName;
  }

  public static String getPASSWORD() {
    return PASSWORD;
  }

  public static void setPASSWOR(String PASSWORD) {
    DatasourceParamsConfig.PASSWORD = PASSWORD;
  }

  public static String getVerifyServerCertificate() {
    return VERIFY_SERVER_CERTIFICATE;
  }

  public static void setVerifyServerCertificate(String verifyServerCertificate) {
    VERIFY_SERVER_CERTIFICATE = verifyServerCertificate;
  }

  public static String getUseSsl() {
    return USE_SSL;
  }

  public static void setUseSsl(String useSsl) {
    USE_SSL = useSsl;
  }
}
