package com.goodies.datasource.constants;

/**
 * @Author: pxp167
 * @Date: 9/26/2018
 *
 */
public class ApplicationConstants {

  public static final String DATE_FORMAT="yyyy.MM.dd  HH:mm:ss z";
  public static final int MINIMUM_WATER_REPO_BALANCE=50;
  public static final String SSL_CERTIFICATE = "rds-ca-2015-us-east-2.pem";
  public static final String KEY_STORE_TYPE = "JKS";
  public static final String KEY_STORE_PROVIDER = "SUN";
  public static final String KEY_STORE_FILE_PREFIX = "sys-connect-via-ssl-test-cacerts";
  public static final String KEY_STORE_FILE_SUFFIX = ".jks";
  public static final String DEFAULT_KEY_STORE_PASSWORD = "changeit";
}
