package com.goodies.datasource.entity;

import javax.persistence.*;

/**
 * @Author: pxp167
 * @Date: 9/26/2018
 *
 */
@Entity
@Table(name="ADDRESS")
public class Address {
  private static final long serialVersionUID = 1L;
  @Id
  @GeneratedValue(strategy= GenerationType.AUTO)
  @Column(name="ADDRESS_ID")
  private long addressId;
  @Column(name="FLAT_NO")
  private String flatNo;
  @Column(name="BUILDING_NAME")
  private String buildingName;
  @Column(name="CITY")
  private String city;
  @Column(name="STATE")
  private String state;
  @Column(name="COUNTRY")
  private String country;
  @Column(name="PIN_CODE")
  private String pinCode;
  @Column(name="LOCATION")
  private String location;
  @Column(name="LATITUDE")
  private String latitude;
  @Column(name="LONGITUDE")
  private String longitude;

  public long getAddressId() {
    return addressId;
  }

  public void setAddressId(long addressId) {
    this.addressId = addressId;
  }

  public String getFlatNo() {
    return flatNo;
  }

  public void setFlatNo(String flatNo) {
    this.flatNo = flatNo;
  }

  public String getBuildingName() {
    return buildingName;
  }

  public void setBuildingName(String buildingName) {
    this.buildingName = buildingName;
  }

  public String getCity() {
    return city;
  }

  public void setCity(String city) {
    this.city = city;
  }

  public String getState() {
    return state;
  }

  public void setState(String state) {
    this.state = state;
  }

  public String getCountry() {
    return country;
  }

  public void setCountry(String country) {
    this.country = country;
  }

  public String getPinCode() {
    return pinCode;
  }

  public void setPinCode(String pinCode) {
    this.pinCode = pinCode;
  }

  public String getLocation() {
    return location;
  }

  public void setLocation(String location) {
    this.location = location;
  }

  public String getLatitude() {
    return latitude;
  }

  public void setLatitude(String latitude) {
    this.latitude = latitude;
  }

  public String getLongitude() {
    return longitude;
  }

  public void setLongitude(String longitude) {
    this.longitude = longitude;
  }

}
