package com.goodies.datasource.entity;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * @Author: pxp167
 * @Date: 9/26/2018
 *
 */
@Entity
@Table(name="Orders")
public class Order {
  private static final long serialVersionUID = 1L;
  @Id
  @GeneratedValue(strategy= GenerationType.AUTO)
  @Column(name="Order_ID")
  private long orderID;
  @Column(name="Razorpay_id")
  private String razorpayId;
  @Column(name="Order_Status")
  private String orderStatus;
  @Column(name="Delivery_Status")
  private String deliveryStatus;
  @Column(name="user_ID")
  private long userId;
  @OneToMany(cascade = CascadeType.ALL, orphanRemoval = true)
  private List<Purchase> products =new ArrayList<>();
  @Column(name="Order_Date")
  private Date orderDate;

  public long getOrderID() {
    return orderID;
  }

  public void setOrderID(long orderID) {
    this.orderID = orderID;
  }

  public String getOrderStatus() {
    return orderStatus;
  }

  public void setOrderStatus(String orderStatus) {
    this.orderStatus = orderStatus;
  }

  public String getDeliveryStatus() {
    return deliveryStatus;
  }

  public void setDeliveryStatus(String deliveryStatus) {
    this.deliveryStatus = deliveryStatus;
  }

  public Date getOrderDate() {
    return orderDate;
  }

  public void setOrderDate(Date orderDate) {
    this.orderDate = orderDate;
  }

  public List<Purchase> getProducts() {
    return products;
  }

  public void setProducts(List<Purchase> products) {
    this.products = products;
  }

  public long getUserId() {
    return userId;
  }

  public void setUserId(long userId) {
    this.userId = userId;
  }

  public String getRazorpayId() {
    return razorpayId;
  }

  public void setRazorpayId(String razorpayId) {
    this.razorpayId = razorpayId;
  }
}
